#include "FormulaParser.h"
#include <cmath>
#include <iostream>
namespace parser{

    double FormulaParser::SUM(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &grid, int maxRowCount, int maxColCount)
    {
        // input syntax should be like that =SUM(A1..A10)
        std::string lhs, rhs;
        int lhi1 = 0, lhi2 = 0, rhi1 = 0, rhi2 = 0;
        int i = 5;
        while (formula[i] != '.' && i < formula.size())
        {
            lhs += formula[i];
            i++;
        }
        i += 2;
        while (i < formula.size())
        {
            rhs += formula[i];
            i++;
        }
        int letterCount = 0, numberCount = 0;
        for (char c : lhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }

        if (letterCount == 1 && numberCount == 1)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += lhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += (lhs[1] - '0') * 10 + (lhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += lhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 10 + (lhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 100 + (lhs[3] - '0') * 10 + (lhs[4] - '1');
        }

        letterCount = 0;
        numberCount = 0;

        for (char c : rhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }
        if (letterCount == 1 && numberCount == 1)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += rhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += (rhs[1] - '0') * 10 + (rhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += rhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 10 + (rhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 100 + (rhs[3] - '0') * 10 + (rhs[4] - '1');
        }

        if (lhi1 != rhi1)
        {
            return 0.0;
        }
        double sum = 0.0;
        for (int row = lhi2; row <= rhi2; ++row)
        {
            if (row >= 0 && row < maxRowCount && lhi1 >= 0 && lhi1 < maxColCount && grid[row][lhi1])
            {
                sum += grid[row][lhi1]->getValue();
            }
        }
        return sum;
    }

    double FormulaParser::AVER(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &grid, int maxRowCount, int maxColCount)
    {
        std::string lhs, rhs;
        int lhi1 = 0, lhi2 = 0, rhi1 = 0, rhi2 = 0;
        int i = 6;
        while (formula[i] != '.' && i < formula.size())
        {
            lhs += formula[i];
            i++;
        }
        i += 2;
        while (i < formula.size())
        {
            rhs += formula[i];
            i++;
        }
        int letterCount = 0, numberCount = 0;
        for (char c : lhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }

        if (letterCount == 1 && numberCount == 1)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += lhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += (lhs[1] - '0') * 10 + (lhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += lhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 10 + (lhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 100 + (lhs[3] - '0') * 10 + (lhs[4] - '1');
        }

        letterCount = 0;
        numberCount = 0;

        for (char c : rhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }
        if (letterCount == 1 && numberCount == 1)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += rhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += (rhs[1] - '0') * 10 + (rhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += rhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 10 + (rhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 100 + (rhs[3] - '0') * 10 + (rhs[4] - '1');
        }

        if (lhi1 != rhi1)
        {
            return 0.0;
        }
        double sum = 0.0;
        int count = 0;
        for (int row = lhi2; row <= rhi2; ++row)
        {
            if (row >= 0 && row < maxRowCount && lhi1 >= 0 && lhi1 < maxColCount && grid[row][lhi1])
            {
                sum += grid[row][lhi1]->getValue();
                count++;
            }
        }
        return sum / count;
    }

    double FormulaParser::MAX(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &grid, int maxRowCount, int maxColCount)
    {
        double max=-99999999;
        std::string lhs, rhs;
        int lhi1 = 0, lhi2 = 0, rhi1 = 0, rhi2 = 0;
        int i = 5;
        while (formula[i] != '.' && i < formula.size())
        {
            lhs += formula[i];
            i++;
        }
        i += 2;
        while (i < formula.size())
        {
            rhs += formula[i];
            i++;
        }
        int letterCount = 0, numberCount = 0;
        for (char c : lhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }

        if (letterCount == 1 && numberCount == 1)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += lhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += (lhs[1] - '0') * 10 + (lhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += lhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 10 + (lhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 100 + (lhs[3] - '0') * 10 + (lhs[4] - '1');
        }

        letterCount = 0;
        numberCount = 0;

        for (char c : rhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }

        if (letterCount == 1 && numberCount == 1)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += rhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += (rhs[1] - '0') * 10 + (rhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += rhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 10 + (rhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 100 + (rhs[3] - '0') * 10 + (rhs[4] - '1');
        }
    

    if(lhi1 != rhi1)
    {
        return 0.0;
    }
    for (int row = lhi2; row <= rhi2; ++row)
    {
        if (row >= 0 && row < maxRowCount && lhi1 >= 0 && lhi1 < maxColCount && grid[row][lhi1])
        {
            if(grid[row][lhi1]->getValue() > max){
                max = grid[row][lhi1]->getValue();
            }

        }
    }
    if(max == -99999999){
        return 0.0;
    }
    return max;
}

    double FormulaParser::MIN(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &grid, int maxRowCount, int maxColCount)
    {
        double min = 99999999;
        std::string lhs, rhs;
        int lhi1 = 0, lhi2 = 0, rhi1 = 0, rhi2 = 0;
        int i = 5;
        while (formula[i] != '.' && i < formula.size())
        {
            lhs += formula[i];
            i++;
        }
        i += 2;
        while (i < formula.size())
        {
            rhs += formula[i];
            i++;
        }
        int letterCount = 0, numberCount = 0;
        for (char c : lhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }

        if (letterCount == 1 && numberCount == 1)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += lhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += (lhs[1] - '0') * 10 + (lhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += lhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 10 + (lhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 100 + (lhs[3] - '0') * 10 + (lhs[4] - '1');
        }

        letterCount = 0;
        numberCount = 0;

        for (char c : rhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }

        if (letterCount == 1 && numberCount == 1)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += rhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += (rhs[1] - '0') * 10 + (rhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += rhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 10 + (rhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 100 + (rhs[3] - '0') * 10 + (rhs[4] - '1');
        }

        if (lhi1 != rhi1)
        {
            return 0.0;
        }

        for (int row = lhi2; row <= rhi2; ++row)
        {
            if (row >= 0 && row < maxRowCount && lhi1 >= 0 && lhi1 < maxColCount && grid[row][lhi1])
            {
                if (grid[row][lhi1]->getValue() < min)
                {
                    min = grid[row][lhi1]->getValue();
                }
            }
        }

        if (min == 99999999)
        {
            return 0.0;
        }
        return min;
    }

    double FormulaParser::STDDEV(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &grid, int maxRowCount, int maxColCount)
    {
        // formula of standard deviation is sqrt((sum of (x - mean)^2) / n)
        // mean is the average of the values in the range
        // n is the number of values in the range
        // formula should be like that =STDDEV(A1..A10)
        std::string lhs, rhs;
        int lhi1 = 0, lhi2 = 0, rhi1 = 0, rhi2 = 0;
        int i = 8;
        while (formula[i] != '.' && i < formula.size())
        {
            lhs += formula[i];
            i++;
        }
        i += 2;
        while (i < formula.size())
        {
            rhs += formula[i];
            i++;
        }
        int letterCount = 0, numberCount = 0;
        for (char c : lhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }

        if (letterCount == 1 && numberCount == 1)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += lhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += (lhs[1] - '0') * 10 + (lhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += lhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 10 + (lhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 100 + (lhs[3] - '0') * 10 + (lhs[4] - '1');
        }

        letterCount = 0;
        numberCount = 0;

        for (char c : rhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }

        if (letterCount == 1 && numberCount == 1)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += rhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += (rhs[1] - '0') * 10 + (rhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += rhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 10 + (rhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 100 + (rhs[3] - '0') * 10 + (rhs[4] - '1');
        }

        if (lhi1 != rhi1)
        {
            return 0.0;
        }
        std::string newFormula = "=AVER(" + lhs + ".." + rhs + ")";
        double mean = AVER(newFormula, grid, maxRowCount, maxColCount);
        double sumOfSquares = 0.0;
        int count = 0;
        for (int row = lhi2; row <= rhi2; ++row)
        {
            if (row >= 0 && row < maxRowCount && lhi1 >= 0 && lhi1 < maxColCount && grid[row][lhi1])
            {
                sumOfSquares += pow((grid[row][lhi1]->getValue() - mean), 2);
                count++;
            }
        }

        return sqrt(sumOfSquares / count);
    }

    double FormulaParser::calculateFormula(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &grid, int maxRowCount, int maxColCount)
    {
        std::string check = formula.substr(1, 3);
        if (check == "SUM")
        {
            return SUM(formula, grid, maxRowCount, maxColCount);
        }
        else if (check == "AVE")
        {
            return AVER(formula, grid, maxRowCount, maxColCount);
        }
        else if (check == "STD")
        {
            return STDDEV(formula, grid, maxRowCount, maxColCount);
        }
        else if (check == "MAX")
        {
            return MAX(formula, grid, maxRowCount, maxColCount);
        }
        else if (check == "MIN")
        {
            return MIN(formula, grid, maxRowCount, maxColCount);
        }

        std::string lhs, rhs;
        char op;
        int i = 1;
        while (formula[i] != '+' && formula[i] != '-' && formula[i] != '*' && formula[i] != '/' && i < formula.size())
        {
            lhs += formula[i];
            i++;
        }
        op = (i < formula.size()) ? formula[i] : ' ';
        i++;
        while (i < formula.size())
        {
            rhs += formula[i];
            i++;
        }
        double lv, rv;
        int lhi1 = 0, lhi2 = 0, rhi1 = 0, rhi2 = 0;
        int letterCount = 0, numberCount = 0;
        for (char c : lhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }

        if (letterCount == 1 && numberCount == 1)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += lhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            lhi1 += lhs[0] - 'A';
            lhi2 += (lhs[1] - '0') * 10 + (lhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += lhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 10 + (lhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            lhi1 += (lhs[0] - 'A' + 1) * 26 + (lhs[1] - 'A');
            lhi2 += (lhs[2] - '0') * 100 + (lhs[3] - '0') * 10 + (lhs[4] - '1');
        }

        if (op == ' ')
        {
            if (lhi2 >= 0 && lhi2 < maxRowCount && lhi1 >= 0 && lhi1 < maxColCount && grid[lhi2][lhi1])
            {
                return grid[lhi2][lhi1]->getValue();
            }
            else
                return 0.0;
        }

        letterCount = 0;
        numberCount = 0;
        for (char c : rhs)
        {
            if (isalpha(c))
            {
                letterCount++;
            }
            else if (isdigit(c))
            {
                numberCount++;
            }
        }

        if (letterCount == 1 && numberCount == 1)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += rhs[1] - '1';
        }
        else if (letterCount == 1 && numberCount == 2)
        {
            rhi1 += rhs[0] - 'A';
            rhi2 += (rhs[1] - '0') * 10 + (rhs[2] - '1');
        }
        else if (letterCount == 2 && numberCount == 1)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += rhs[2] - '1';
        }
        else if (letterCount == 2 && numberCount == 2)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 10 + (rhs[3] - '1');
        }
        else if (letterCount == 2 && numberCount == 3)
        {
            rhi1 += (rhs[0] - 'A' + 1) * 26 + (rhs[1] - 'A');
            rhi2 += (rhs[2] - '0') * 100 + (rhs[3] - '0') * 10 + (rhs[4] - '1');
        }

        if (lhi2 >= 0 && lhi2 < maxRowCount && lhi1 >= 0 && lhi1 < maxColCount && grid[lhi2][lhi1])
        {
            lv = grid[lhi2][lhi1]->getValue();
        }
        else
        {
            lv = 0.0;
        }

        if (rhi2 >= 0 && rhi2 < maxRowCount && rhi1 >= 0 && rhi1 < maxColCount && grid[rhi2][rhi1])
        {
            rv = grid[rhi2][rhi1]->getValue();
        }
        else
        {
            rv = 0.0;
        }

        switch (op)
        {
        case '+':
            return lv + rv;
        case '-':
            return lv - rv;
        case '*':
            return lv * rv;
        case '/':
            return lv / rv;
        }

        return 0.0;
    }
    }