#ifndef SPREADSHEET_H
#define SPREADSHEET_H
#include "AnsiTerminal.h"
#include "Cell.h"
#include "FormulaParser.h"
#include <string>
#include <memory>
namespace sheet{


    class Spreadsheet
    {
    public:
        Spreadsheet();
        ~Spreadsheet() = default;
        AnsiTerminal &getTerminal();
        std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &getGrid() { return grid; }
        void printSpreadsheet(int row, int col);
        void input(std::string input, int row, int col);
        void updateSize(int row, int col);
        void setVerticalScrollNum(int num) { verticalScrollNum = num; }
        void setHorizontalScrollNum(int num) { horizontalScrollNum = num; }
        int getVerticalScrollNum() { return verticalScrollNum; }
        int getHorizontalScrollNum() { return horizontalScrollNum; }
        int getRow() { return row; }
        int getCol() { return col; }
        void setRow(int r) { row = r; }
        void setCol(int c) { col = c; }
        void readFile(std::string filename);
        void saveFile(std::string filename);

    private:
        int row = 4;
        int col = 5;
        int verticalScrollNum = 0;
        int horizontalScrollNum = 0;
        int maxRow = 18;
        int maxCol = 13;
        std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> grid;
        AnsiTerminal terminal;
        parser::FormulaParser parser;
    };
} // namespace sheet
#endif