#ifndef CELL_H
#define CELL_H
namespace cell
{
#include <string>
    class Cell
    {
    public:
        Cell() = default;
        virtual ~Cell() = default;
        virtual std::string getStringVersion() const = 0; 
        virtual double getValue() const = 0;
        virtual void setValue(double val) = 0;
};

class ValueCell : public Cell
{
public:
    ValueCell() = default;
    ~ValueCell() override = default;
};

class FormulaCell : public Cell
{
    public:
        FormulaCell() : formula(""){}
        FormulaCell(std::string str) : formula(str){}
        ~FormulaCell() override = default;
        std::string getStringVersion() const override {
            return formula;
        }
        void setValue(double val) override {
            value = val;
        }
        double getValue() const override {
            return value;
        }
    private:
        std::string formula;
        double value;
};

class IntValueCell : public ValueCell
{
    public:
        IntValueCell() : intValue(0) {}
        IntValueCell(int i) : intValue(i) {}
        ~IntValueCell() override = default;
        std::string getStringVersion() const override { return std::to_string(intValue); }
        double getValue() const override { return intValue; }
        void setValue(double val) override {
            intValue = val;
        }
    private:
        int intValue;
};

class DoubleValueCell : public ValueCell
{
    public:
        DoubleValueCell() : doubleValue(0.0) {}
        DoubleValueCell(double d) : doubleValue(d) {}
        ~DoubleValueCell() override = default;
        std::string getStringVersion() const override { return std::to_string(doubleValue); }
        double getValue() const override { return doubleValue; }
        void setValue(double val) override {
            doubleValue = val;
        }
    private:
        double doubleValue;
};

class StringValueCell : public ValueCell
{
    public:
        StringValueCell() : stringValue("") {}
        StringValueCell(std::string str) : stringValue(str) {}
        ~StringValueCell() override = default;
        std::string getStringVersion() const override { return stringValue; }
        double getValue() const override { return 0.0; }
        void setValue(double val) override {
            stringValue = std::to_string(val);
        }
    private:
        std::string stringValue;
};

} // namespace cell
#endif
