#include "SpreadSheet.h"
#include "AnsiTerminal.h"
#include <iostream>
#include <string>

int main() {
    sheet::Spreadsheet S;
    S.getTerminal().clearScreen(); // Clear the screen at the beginning
    std::string inputStr;
    S.printSpreadsheet(S.getRow(), S.getCol());
    char key;
    //S.readFile("test.csv");
    while (true) {
        key = S.getTerminal().getSpecialKey();
        // Clear the previous position
        S.getTerminal().printAt(S.getRow(), S.getCol(), "    ");
        
        try {
            if (S.getVerticalScrollNum() > 999 || S.getHorizontalScrollNum() > 685) {
                throw std::out_of_range("Out Of Range");
            }
        } catch (const std::out_of_range& e) {
            S.setVerticalScrollNum(0);
            S.setHorizontalScrollNum(0); 
            S.setRow(4);
            S.setCol(5);
        }
        switch (key) {
            case 'U': 
                if(S.getRow() > 4) S.setRow(S.getRow() - 1);                                                                                                        
                else if(S.getVerticalScrollNum() > 0) S.setVerticalScrollNum(S.getVerticalScrollNum() - 1);
                break; // Up
            case 'D': 
                if(S.getRow() < 21) S.setRow(S.getRow() + 1);
                else S.setVerticalScrollNum(S.getVerticalScrollNum() + 1);
                break; // Down
            case 'R': 
                if(S.getCol() < 64) S.setCol(S.getCol() + 5); 
                else S.setHorizontalScrollNum(S.getHorizontalScrollNum() + 1);    
                break; // Right
            case 'L':
                if(S.getCol() > 5) S.setCol(S.getCol() - 5);
                else if(S.getHorizontalScrollNum() > 0) S.setHorizontalScrollNum(S.getHorizontalScrollNum() - 1);
                break; // Left
            case '\r' :  // Show cursor
                S.getTerminal().printAt(2, 1, "                            "); // Clear the input line
                S.getTerminal().printAt(2, 1, ""); // Show cursor
                char ch;
                inputStr.clear();
                while (true)
                {
                    ch = std::cin.get();
                    if (ch == '\r' || ch == '\n')
                    {
                        break; // Enter key
                    }
                    else if (ch == '\b' || ch == 127)
                    {
                        if (!inputStr.empty())
                        {
                            inputStr.pop_back();                                  // Handle backspace
                            S.getTerminal().printAt(2, 1 + inputStr.size(), " "); // Clear the last character on screen
                            S.getTerminal().printAt(2, 1, inputStr + " ");        // Show updated input with cursor
                        }
                    }
                    else
                    {
                        inputStr += ch;
                        S.getTerminal().printAt(2, 1, inputStr); // Show updated input with cursor
                    }
                }
                S.input(inputStr, S.getRow(), S.getCol());
                S.getTerminal().printAt(25, 4, inputStr);
                break;  // Return key
            case '"': S.saveFile("save.csv"); return 0; // Quit program if '"' is pressed         
                break;
        }
        S.printSpreadsheet(S.getRow(), S.getCol());
    }
    S.saveFile("save.csv");
    S.getTerminal().clearScreen(); // Clear the screen on exit
    return 0;
}
