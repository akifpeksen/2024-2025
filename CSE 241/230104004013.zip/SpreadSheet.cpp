#include "SpreadSheet.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

namespace sheet {

    Spreadsheet::Spreadsheet()
    {
        AnsiTerminal terminal;
        grid = std::make_unique<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]>(18);
        for (int i = 0; i < 18; i++)
        {
            grid[i] = std::make_unique<std::shared_ptr<cell::Cell>[]>(13);
        }
    }

    AnsiTerminal &Spreadsheet::getTerminal()
    {
        return terminal;
    }

    void Spreadsheet::printSpreadsheet(int row, int col)
    {
        updateSize(row, col);
        terminal.printAt(2, 1, "                                                                                ");
        for (int i = 0; i < maxRow; i++)
        {
            for (int j = 0; j < maxCol; j++)
            {
                if (grid[i][j])
                {
                    if (auto formulaCell = std::dynamic_pointer_cast<cell::FormulaCell>(grid[i][j]))
                    {
                        formulaCell->setValue(parser.calculateFormula(formulaCell->getStringVersion(), getGrid(), maxRow, maxCol));
                    }
                }
            }
        }
        for (int i = 1; i < 19; i++)
        {
            terminal.printInvertedAt(i + 3, 2, "   ");
            if (i + verticalScrollNum < 10)
            {
                terminal.printInvertedAt(i + 3, 1, " 0" + std::to_string(i + verticalScrollNum));
            }
            else if (i + verticalScrollNum < 100)
            {
                terminal.printInvertedAt(i + 3, 1, " " + std::to_string(i + verticalScrollNum));
            }
            else
            {
                terminal.printInvertedAt(i + 3, 1, std::to_string(i + verticalScrollNum));
            }
        }
        for (int i = 1; i < 14; i++)
        {
            int colIndex = i + horizontalScrollNum - 1;
            std::string colLabel;
            if (colIndex < 26)
            {
                colLabel = std::string(1, 'A' + colIndex);
            }
            else
            {
                colLabel = std::string(1, 'A' + (colIndex / 26) - 1) + std::string(1, 'A' + (colIndex % 26));
            }
            terminal.printInvertedAt(3, i * 5, "  " + colLabel + "  ");
        }

        std::string colLabel;
        int colIndex = ((col - 4) / 5) + horizontalScrollNum;
        if (colIndex < 26)
        {
            colLabel = std::string(1, 'A' + colIndex);
            terminal.printInvertedAt(1, 2, std::to_string(row - 3 + verticalScrollNum) + (row - 3 < 10 ? "    " : (row - 3 < 100 ? "   " : "  ")));
            terminal.printInvertedAt(1, 1, colLabel);
        }
        else
        {
            colLabel = std::string(1, 'A' + (colIndex / 26) - 1) + std::string(1, 'A' + (colIndex % 26));
            terminal.printInvertedAt(1, 3, std::to_string(row - 3 + verticalScrollNum) + (row - 3 < 10 ? "    " : (row - 3 < 100 ? "   " : "  ")));
            terminal.printInvertedAt(1, 1, colLabel);
        }
        for (int i = 0; i < 63; i++)
        {
            terminal.printInvertedAt(1, i + 6, " .");
        }
        for (int i = 0; i < 18; i++)
        {
            for (int j = 0; j < 13; j++)
            {
                terminal.printAt(i + 4, (j + 1) * 5, "     ");
                if (grid[i + verticalScrollNum][j + horizontalScrollNum])
                {
                    if (auto formulaCell = std::dynamic_pointer_cast<cell::FormulaCell>(grid[i + verticalScrollNum][j + horizontalScrollNum]))
                    {
                        terminal.printAt(i + 4, (j + 1) * 5, std::to_string(formulaCell->getValue()).substr(0, 5));
                    }
                    else
                        terminal.printAt(i + 4, (j + 1) * 5, (grid[i + verticalScrollNum][j + horizontalScrollNum]->getStringVersion()).substr(0, 5));
                }
            }
        }
        terminal.printInvertedAt(row, col, "    ");
        if (grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum])
        {

            if (auto formulaCell = std::dynamic_pointer_cast<cell::FormulaCell>(grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum]))
            {
                terminal.printInvertedAt(row, col, std::to_string(formulaCell->getValue()).substr(0, 5));
                terminal.printAt(2, 1, (grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum]->getStringVersion()).substr(0, 80));
            }
            else
            {
                std::string cellContent = (grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum]->getStringVersion()).substr(0, 5);
                int padding;
                if (cellContent.length() <= 5)
                    padding = 5 - cellContent.length();
                else
                    padding = 0;
                terminal.printInvertedAt(row, col, cellContent + std::string(padding, ' '));
                terminal.printAt(2, 1, (grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum]->getStringVersion()).substr(0, 80));
            }
        }
    }
  
    void Spreadsheet::input(std::string input, int row, int col)
    {

        updateSize(row, col);
      
        if (input.empty()) {
            grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum] = nullptr;
        }
        else if (input.find_first_not_of("0987654321-") == std::string::npos) {
            grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum] = std::make_shared<cell::IntValueCell>(std::stoi(input));
        }
        else if (input.find_first_not_of("0987654321.-") == std::string::npos) {
            grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum] = std::make_shared<cell::DoubleValueCell>(std::stod(input));
        }
        else if (input.front() == '=') {
            grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum] = std::make_shared<cell::FormulaCell>(input);
            grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum]->setValue(parser.calculateFormula(input, getGrid(), maxRow, maxCol));
        }
        else {
            grid[row - 4 + verticalScrollNum][col / 5 - 1 + horizontalScrollNum] = std::make_shared<cell::StringValueCell>(input);
        }

    }

    void Spreadsheet::updateSize(int row, int col){
        int newRowSize = row - 4 + verticalScrollNum + 1;
        int newColSize = col / 5 + horizontalScrollNum + 1;

        if (maxRow < newRowSize) {
            auto newGrid = std::make_unique<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]>(newRowSize);
            for (int i = 0; i < newRowSize; i++) {
                if (i < maxRow) {
                    newGrid[i] = std::move(grid[i]);
                } else {
                    newGrid[i] = std::make_unique<std::shared_ptr<cell::Cell>[]>(maxCol);
                }
            }
            maxRow = newRowSize;
            grid = std::move(newGrid);
        }

        if (maxCol < newColSize) {
            
            for (int i = 0; i < maxRow; i++) {
                auto newRow = std::make_unique<std::shared_ptr<cell::Cell>[]>(newColSize);
                for (int j = 0; j < maxCol; j++) {
                    newRow[j] = std::move(grid[i][j]);
                }
                grid[i] = std::move(newRow);
            }
            maxCol = newColSize;
        }
    }

    void Spreadsheet::readFile(std::string filename){
        try {
            std::ifstream file(filename);
            if (!file.is_open()) {
                throw std::runtime_error("Error: File not found");
            }
            std::string line;
            int row = 0;
            while (std::getline(file, line)) {
                if (row >= 18) {
                    throw std::runtime_error("Error: File has too many rows");
                }
                std::istringstream iss(line);
                std::string cell;
                int col = 0;
                while (std::getline(iss, cell, ';')) {
                    if (col >= 13) {
                        throw std::runtime_error("Error: File has too many columns");
                    }
                    if (cell.empty()) {
                        grid[row][col] = nullptr;
                    }
                    else if (cell.find_first_not_of("0987654321-") == std::string::npos) {
                        grid[row][col] = std::make_shared<cell::IntValueCell>(std::stoi(cell));
                    }
                    else if (cell.find_first_not_of("0987654321.-") == std::string::npos) {
                        grid[row][col] = std::make_shared<cell::DoubleValueCell>(std::stod(cell));
                    }
                    else if (cell.front() == '=') {
                        grid[row][col] = std::make_shared<cell::FormulaCell>(cell);
                        grid[row][col]->setValue(parser.calculateFormula(cell, getGrid(), maxRow, maxCol));
                    }
                    else {
                        grid[row][col] = std::make_shared<cell::StringValueCell>(cell);
                    }
                    col++;
                }
                row++;
            }
            file.close();
        } catch (const std::exception& e) {
            std::cerr << e.what() << std::endl;
        }
    }

    void Spreadsheet::saveFile(std::string filename){
        try {
            std::ofstream file(filename);
            if (!file.is_open()) {
                throw std::runtime_error("Error: File not found");
            }
            for (int i = 0; i < maxRow; i++) {
                for (int j = 0; j < maxCol; j++) {
                    if (grid[i][j]) {
                        file << grid[i][j]->getStringVersion();
                    }
                    if (j < maxCol - 1) {
                        file << ";";
                    }
                }
                file << std::endl;
            }
            file.close();
        } catch (const std::exception& e) {
            std::cerr << e.what() << std::endl;
        }
    }
} // namespace sheet
