#ifndef FORMULAPARSER_H
#define FORMULAPARSER_H
#include <string>
#include "Cell.h"
#include <memory>

namespace parser{

    class FormulaParser{
    
    public:
    FormulaParser() = default;
    ~FormulaParser() = default;
    double SUM(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]>& grid, int maxRowCount, int maxColCount); // returns the sum of the values in the range (A1..A10)
    double AVER(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]>& grid, int maxRowCount, int maxColCount); // returns the average of the values in the range (A1..A10)
    double STDDEV(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &grid, int maxRowCount, int maxColCount); // returns the standard deviation of the values in the range (A1..A10)
    double MAX(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &grid, int maxRowCount, int maxColCount);    // returns the maximum value in the range (A1..A10)
    double MIN(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &grid, int maxRowCount, int maxColCount);    // returns the minimum value in the range (A1..A10)
    double calculateFormula(std::string formula, std::unique_ptr<std::unique_ptr<std::shared_ptr<cell::Cell>[]>[]> &grid, int maxRowCount, int maxColCount);
};

} // namespace parser
#endif